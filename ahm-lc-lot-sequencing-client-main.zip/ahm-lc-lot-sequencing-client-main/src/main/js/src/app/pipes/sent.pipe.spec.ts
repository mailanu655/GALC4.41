import { SentPipe } from './sent.pipe';

describe('SentPipe', () => {
  it('create an instance', () => {
    const pipe = new SentPipe();
    expect(pipe).toBeTruthy();
  });
});
