export default class Category {  
    categoryId: number;
    name: string;
    description: string;
    createTimestamp:string;
    updateTimestamp:string;
    createdBy:string;
    updatedBy:string;
}
    