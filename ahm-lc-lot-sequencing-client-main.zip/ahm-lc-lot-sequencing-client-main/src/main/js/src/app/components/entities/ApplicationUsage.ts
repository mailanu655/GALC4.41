export default class ApplicationUsage {  
    applicationUsageId: number;
    application: string;
    host: string;
    user:string;
    createdOn:string;    
}