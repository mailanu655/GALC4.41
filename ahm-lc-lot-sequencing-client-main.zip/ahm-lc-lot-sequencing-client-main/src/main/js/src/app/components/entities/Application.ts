export default class Application {  
    applicationId: number;
    name: string;
    description: string;
    url:string;
    createTimestamp:string;
    updateTimestamp:string;
    createdBy:string;
    updatedBy:string;
    client:string;
    icon:string;
}
    