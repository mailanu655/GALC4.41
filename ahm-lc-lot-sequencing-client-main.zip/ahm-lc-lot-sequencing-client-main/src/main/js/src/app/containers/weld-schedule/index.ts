export * from './weld-schedule.component';
