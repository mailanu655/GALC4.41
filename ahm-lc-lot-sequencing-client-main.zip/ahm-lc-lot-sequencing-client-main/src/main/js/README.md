# lc-weld-schedule
This project is used to create the UI part for Weld Schedule project.
